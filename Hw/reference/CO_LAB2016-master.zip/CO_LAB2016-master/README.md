# NCTU Computer Organization lab

This is our first verilog lab. Feel free to comment issue or send us pull request.  
Copy and paste for your homework is not a right thing to do. Be honest.

### Team member
- [sunset1995](https://github.com/sunset1995)
- [oiu850714](https://github.com/oiu850714)

